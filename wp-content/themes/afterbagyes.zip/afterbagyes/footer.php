<?php
do_action( 'afterbagyes_footer_style' );

wp_footer();
?>
</body>
</html>