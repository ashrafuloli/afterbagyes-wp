<?php
/**
 * Template Name: Afterbagyes Page Template
 */
get_header();
	the_content();
get_footer();
?>
