{
    "icons" = [
      "arrow-right",
      "arrow-left",
      "arrow-up",
      "arrow-down",
      "long-arrow-right",
      "long-arrow-left",
      "long-arrow-up",
      "long-arrow-down",
      "bullhorn",
      "ribbon",
      "times",
      "calendar-alt",
      "comments"    
  ]
}
