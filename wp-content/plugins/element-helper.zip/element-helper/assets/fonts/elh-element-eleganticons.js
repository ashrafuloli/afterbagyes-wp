{
    "icons" = [
        "icon_tools",
        "icon_ribbon_alt",
        "icon_heart_alt",
        "icon_bag_alt",
        "icon_book_alt",
        "icon_lightbulb_alt",
        "icon_house_alt",
        "icon_document_alt",
        "icon_lock_alt"
    ]
}